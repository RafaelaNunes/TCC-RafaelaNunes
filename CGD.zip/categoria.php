<!DOCTYPE html>
<html>
<head>
	<title>CDG</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="CSS/estilo_tabela.css">
	
</head>


<body>


<?php 
	include "conexao.php";
	include('verifica_login.php');

    $id= $_GET['idobra'] ?? '';

	$sql = "SELECT * FROM  categoria WHERE idobra ='".$id."' ";

	$dados = mysqli_query($conexao, $sql);
	$linha = mysqli_fetch_assoc($dados);
	$nome=$linha['nome'];
	
	?>

<!--------------------------------------  TOPO------------------------------ -->
<div class="topo">

	<input type="checkbox" id="check">
	<label id="icone" for="check"><img width="30" height="33" src="Imagens/icone.png"></label>

	<div class="barra">
		
		<nav>
			<a href="index.php"><div class="link"> Home</div></a>
			<a href="obras.php"><div class="link"> Minhas Obras</div></a>
			  <div class="link"><?php echo "<a href ='categoria.php?idobra=$id' class='editar'> Categoria</a> <br> "; ?></div>
			<a href="produtos.php"><div class="link"> Produtos</div></a>
			<a href="materiais.php"><div class="link"> Materiais</div></a>
			<div class="link"><?php echo "<a href ='perfil_obra.php?idobra=$id' class='editar'> Perfil Obra</a> <br> "; ?></div>
			<a href="logout.php"><div class="link"> Sair</div></a>
			
		</nav>
	</div>
</div>
<!-------------------------------------- -- FIM DO TOPO------------------------------ -->


 <div class="conteinerTabela">

		
	<table  class="tabelaCategoria">
	<tr>
        <td class="tituloTabela">Nome</td> <td class="tituloTabela">&nbsp;</td>  <td class="tituloTabela">&nbsp;</td>
    </tr>


     
    <?php
    
	                 
	echo "<tr>";
	while ($linha = mysqli_fetch_assoc($dados)) {
	 
                     $nome=$linha['nome'];
                     $idobra=$linha['idobra']; 
                     $idcategoria=$linha['idcategoria'];
                     
		

     echo " <td class='linhaTabela'>  $nome";

                 
                    echo "  </td>   
                      <td class='tamanho' > <div class='linkeditar'> <a href ='editar_categoria.php?idcategoria=$idcategoria&&idobra=$id&&nome=$nome' class='link2' > Editar</a> </div>  </td> 

                      <td class='tamanho'> <div class='linkexluir'> <a href ='excluir_categoria.php?idcategoria=$idcategoria&&idobra=$id' class='link2' > Excluir</a></div></td>
    
    </tr>";
}
    ?>
     
</table>


		        
		        
			
		</div>
			<div class="divAdd"><?php echo "<a href ='add_categoria.php?idobra=$id' class='linkAdd'> Nova Categoria</a> <br> "; ?></div>
			

</body>
</html>