<?php 
session_start();
include('conexao.php');



$idcategoria =  $_GET['idcategoria'];
$idobra =  $_GET['idobra'];



//if ($nome != null && $dataInicio != null && $dataPrevisao != null && $valorEstimado != null ) {
	 $sql = "delete from categoria where idcategoria = ".$idcategoria;
	//}

if (mysqli_query($conexao, $sql) or die( mysqli_error($conexao ) )) {
	
    echo"<script type='text/javascript'>
 window.location.href='categoria.php?idobra=$idobra'</script>";
     
    


	
		}else{
			echo"<script type='text/javascript'>
    alert('ERRO');
   window.location.href='categoria.php'</script>";
	
			}
		
	


?>