<?php 
session_start();
include('conexao.php');




$idobra =  $_GET['idobra'];




//if ($nome != null && $dataInicio != null && $dataPrevisao != null && $valorEstimado != null ) {
	 $sql = "delete categoria  where idobra = ".$idobra;
	 
	//}

if (mysqli_query($conexao, $sql) or die( mysqli_error($conexao ) )) {
	
    echo"<script type='text/javascript'>
 alert('ERRO');' </script>";
     }else{
			echo"<script type='text/javascript'>
    alert('ERRO');
   window.location.href='obras.php'</script>";
	
			}

	


?>