<!DOCTYPE html>
<html>
<head>
	<title>CDG</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="CSS/estilo.css">
	
</head>


<body>
<div class="topo">


	

	<input type="checkbox" id="check">
	<label id="icone" for="check"><img width="30" height="33" src="Imagens/icone.png"></label>

	<div class="barra">
		
		<nav>
			<a href="index.php"><div class="link"> Home</div></a>
			<a href="obras.php"><div class="link"> Minhas Obras</div></a>
			<a href="categoria.php"><div class="link"> Categoria</div></a>
			<a href="produtos.php"><div class="link"> Produtos</div></a>
			<a href="materiais.php"><div class="link"> Materiais</div></a>
			<a href="perfil_obra.php"><div class="link"> Infromaões Obra</div></a>
			<a href="logout.php"><div class="link"> Sair</div></a>
			
		</nav>
	</div>
</div>

<?php 
	include "conexao.php";
	include('verifica_login.php');

     $id= $_GET['idobra'] ?? '';

	/*$sql = "SELECT * FROM  obra WHERE idobra ='".$id."' ";

	$dados = mysqli_query($conexao, $sql);
	$linha = mysqli_fetch_assoc($dados);*/
	echo $id;
	
	?>

	<h1> ----------------------------------------------------</h1>
	<?php
$var = 'Bob';
$Var = 'Joe';
echo "$var, $Var";      // exibe "Bob, Joe"


?>




</body>
</html>